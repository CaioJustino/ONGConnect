<!-- Não precisa mexer nesse arquivo, pois ele só irá renderizar as outras páginas -->
<template>
  <!-- Aqui é onde os componentes das rotas serão renderizados -->
  <router-view></router-view>
</template>