# IMPORTS
from flask import jsonify, Blueprint, request
from models import User
from utils import lm
from flask_login import login_user, login_required, logout_user
import hashlib

# CONFIGS
bp_user = Blueprint("user", __name__)

# ROTAS

# LOGIN
@bp_user.route('/login', methods=['POST'])
def login():
  email = request.args.get('email')
  senha = hashlib.sha256(request.args.get('senha').encode()).hexdigest()

  if User.query.filter_by(email = email).filter_by(senha = senha).count() == 1:
    user = User.query.filter_by(email = email).first()
    login_user(user)
    response = {
      'status': 'success',
      'message': 'User logged in!',
      'data': user.nome 
    }
      
    return jsonify(response), 200

  else:
    response = {
      'status': 'success',
      'message': 'Incorrect data!'
    }
      
    return jsonify(response), 200
  
# LOAD
@lm.user_loader
def load_user(id):
  u = User.query.filter_by(id=id).first()
  return u

# LOGOUT
@bp_user.route('/logout')
@login_required
def logout():
	logout_user()