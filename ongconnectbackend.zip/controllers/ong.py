# IMPORTS
from flask import request, jsonify, Blueprint
from utils import db
from models import User, ONG
from flask_login import login_user, login_required, logout_user
import hashlib

# CONFIGS
bp_ong = Blueprint("ong", __name__)

# ROTAS

# GET
@bp_ong.route('/<int:id>', methods=['GET'])
@login_required
def get(id):
  user = User.query.get(id)
  ong = ONG.query.get(id)
  if ong:
    data = {
      'id': user.id,
      'nome': user.nome,
      'email': user.email,
      'resumo': user.resumo,
      'contato': user.contato,
      'modalidade': ong.modalidade,
      'categoria': ong.categoria,
      'cidade': ong.cidade,
      'uf': ong.uf
    }
    
    response = {
      'status': 'success',
      'data': data,
    }
    
    return jsonify(response), 200

  else:
    response = {
      'message': 'ONG nao encontrada :('
    }
    
    return jsonify(response), 404

# CREATE
@bp_ong.route('/cadastro', methods=['POST'])
def create():
  nome = request.args.get('nome')
  email = request.args.get('email')
  resumo = request.args.get('resumo')
  contato = request.args.get('contato')
  modalidade = request.args.get('modalidade')
  categoria = request.args.get('categoria')
  cidade = request.args.get('cidade')
  uf = request.args.get('uf')
  senha = hashlib.sha256(request.args.get('senha').encode()).hexdigest()
  
  new_user = User(nome, email, resumo, contato, senha, True)
  db.session.add(new_user)
  db.session.commit()
  new_ong = ONG(new_user.id, modalidade, categoria, cidade, uf)
  db.session.add(new_ong)
  db.session.commit()
  login_user(new_user)
  
  response = {
    'status': 'success',
    'message': 'ONG criada!',
  }
    
  return jsonify(response), 200

# UPDATE
@bp_ong.route('/editar/<int:id>', methods=['PUT'])
@login_required
def update(id):
  user = User.query.get(id)
  ong = ONG.query.get(id)
  if ong:
    user.nome = request.args.get('nome')
    user.email = request.args.get('email')
    user.resumo = request.args.get('resumo')
    user.contato = request.args.get('contato')
    ong.modalidade = request.args.get('modalidade')
    ong.categoria = request.args.get('categoria')
    ong.cidade = request.args.get('cidade')
    ong.uf = request.args.get('uf')
    user.senha = hashlib.sha256(request.args.get('senha').encode()).hexdigest()
    db.session.commit()

    response = {
      'status': 'success',
      'message': 'ONG atualizada!',
    }
  
    return jsonify(response), 200

  else:
    response = {
        'message': 'ONG nao encontrada :('
    }
    
    return jsonify(response), 404

# DELETE
@bp_ong.route('/desativar/<int:id>', methods=['PUT'])
@login_required
def delete(id):
  user = User.query.get(id)
  ong = ONG.query.get(id)
  if ong:
    user.status = False
    db.session.commit()
    logout_user()
    
    response = {
    'status': 'success',
    'message': 'ONG deletada!',
    }
  
    return jsonify(response), 200
  
  else:
    response = {
        'message': 'ONG nao encontrada :('
    }
    
    return jsonify(response), 404