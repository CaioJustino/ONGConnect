# IMPORTS
from flask import request, jsonify, Blueprint
from utils import db
from models import User, Voluntario
from flask_login import login_user, login_required, logout_user
import hashlib

# CONFIGS
bp_volut = Blueprint("voluntario", __name__)

# ROTAS

# GET
@bp_volut.route('/<int:id>', methods=['GET'])
@login_required
def get(id):
  user = User.query.get(id)
  volut = Voluntario.query.get(id)
  if volut:
    data = {
      'id': user.id,
      'nome': user.nome,
      'email': user.email,
      'resumo': user.resumo,
      'contato': user.contato,
      'cpf': volut.cpf
    }
    
    response = {
      'status': 'success',
      'data': data,
    }
    
    return jsonify(response), 200

  else:
    response = {
        'message': 'Voluntario nao encontrado :('
    }
    
    return jsonify(response), 404

# CREATE
@bp_volut.route('/cadastro', methods=['POST'])
def create():
  nome = request.args.get('nome')
  email = request.args.get('email')
  resumo = request.args.get('resumo')
  contato = request.args.get('contato')
  cpf = request.args.get('cpf')
  senha = hashlib.sha256(request.args.get('senha').encode()).hexdigest()
  
  new_user = User(nome, email, resumo, contato, senha, True)
  db.session.add(new_user)
  db.session.commit()
  new_client = Voluntario(new_user.id, cpf)
  db.session.add(new_client)
  db.session.commit()
  login_user(new_user)

  response = {
    'status': 'success',
    'message': 'Voluntario criado!',
  }
    
  return jsonify(response), 200

# UPDATE
@bp_volut.route('/editar/<int:id>', methods=['PUT'])
@login_required
def update(id):
  user = User.query.get(id)
  volut = Voluntario.query.get(id)
  if volut:
    user.nome = request.args.get('nome')
    user.email = request.args.get('email')
    user.resumo = request.args.get('resumo')
    user.contato = request.args.get('contato')
    volut.cpf = request.args.get('cpf')
    user.senha = hashlib.sha256(request.args.get('senha').encode()).hexdigest()
    db.session.commit()

    response = {
      'status': 'success',
      'message': 'Voluntario atualizado!',
    }
  
    return jsonify(response), 200

  else:
    response = {
        'message': 'Voluntario nao encontrado :('
    }
    
    return jsonify(response), 404

# DELETE
@bp_volut.route('/desativar/<int:id>', methods=['PUT'])
@login_required
def delete(id):
  user = User.query.get(id)
  volut = Voluntario.query.get(id)
  if volut:
    user.status = False
    db.session.commit()
    logout_user()

    response = {
    'status': 'success',
    'message': 'Cadastro desativado!',
    }
  
    return jsonify(response), 200
  
  else:
    response = {
        'message': 'Voluntario nao encontrado :('
    }
    
    return jsonify(response), 404